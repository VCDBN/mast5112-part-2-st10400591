import React, {useState} from "react";
import {View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Switch,} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';

import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';

const HomeScreen = () => {
  const [lastBook, setLastBook] = useState(null);
  const [totalPages, setTotalPages] = useState(0);
  const [averagePages, setAveragePages] = useState(0);
  const [bookData, setBookData] = useState([]);

  useEffect(() => {
    // Load book data from storage or an API and update bookData state
    // Example: const data = await fetchBookData();
    // setBookData(data);

    // Calculate the last book
    if (bookData.length > 0) {
      const lastBookData = bookData[bookData.length - 1];
      setLastBook(lastBookData);
    }

    // Calculate total pages and average pages
    const pagesArray = bookData.map((book) => book.pages);
    const total = pagesArray.reduce((acc, pages) => acc + pages, 0);
    setTotalPages(total);
    if (bookData.length > 0) {
      setAveragePages(total / bookData.length);
    }
  }, [bookData]);

  return (
    <View style={styles.container}>
      {lastBook && (
        <View style={styles.bookDetails}>
          <Text>Last Book Read:</Text>
          <Text>Title: {lastBook.title}</Text>
          <Text>Author: {lastBook.author}</Text>
          <Text>Genre: {lastBook.genre}</Text>
          <Text>Number of Pages: {lastBook.pages}</Text>
        </View>
      )}
      <View style={styles.statistics}>
        <Text>Total Pages Read: {totalPages}</Text>
        <Text>Average Pages per Book: {averagePages}</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookDetails: {
    marginBottom: 20,
  },
  statistics: {
    borderTopWidth: 1,
    paddingTop: 10,
  },
});

export default HomeScreen;
