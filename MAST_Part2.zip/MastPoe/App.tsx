import React, {useState} from "react";
import {View, Text, TextInput, TouchableOpacity, StyleSheet, Image, Switch,} from 'react-native';

import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from './screens/HomeScreen';
import AddBook from './screens/AddBook';

const Tab = createBottomTabNavigator();

const App = () => {
  return (
    <NavigationContainer>
      <Tab.Navigator>
        <Tab.Screen name="Home" component={HomeScreen} />
        <Tab.Screen name="Add Book" component={AddBook} />
      </Tab.Navigator>
    </NavigationContainer>
  );
};

export default App;
);